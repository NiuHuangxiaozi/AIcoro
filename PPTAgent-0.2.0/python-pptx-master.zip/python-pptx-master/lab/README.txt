This directory is for experimental code that doesn't belong in the
main distribution tree. Generally it either gets developed far enough
to be incorporated in the main branch or it gets archived.
