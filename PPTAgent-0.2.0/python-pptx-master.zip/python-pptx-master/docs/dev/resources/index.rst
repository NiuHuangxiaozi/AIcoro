=========
Resources
=========

... just collected bits and pieces here for now ...

.. toctree::
   :maxdepth: 1

   python_packaging
   about_packaging
   about_relationships
   web_resources
   technical_topics
   applescript
   odds_and_ends

