================
Technical Topics
================

Some technical topics that have become relevant to this project ...


Python Metaclasses
==================

* `Metaclass programming in Python`_
* `Python metaclasses by example`_


.. _`Metaclass programming in Python`:
   http://www.ibm.com/developerworks/linux/library/l-pymeta/index.html

.. _`Python metaclasses by example`:
   http://eli.thegreenplace.net/2011/08/14/python-metaclasses-by-example/



