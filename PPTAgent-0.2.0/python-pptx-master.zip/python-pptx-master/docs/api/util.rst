.. _util:

:mod:`util` Module
------------------

.. automodule:: pptx.util
   :members:
   :exclude-members: Collection, lazyproperty, to_unicode
   :member-order: bysource
   :undoc-members:
   :show-inheritance:

