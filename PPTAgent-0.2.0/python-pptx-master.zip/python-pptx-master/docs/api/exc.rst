.. _exceptions:

Exceptions
==========

.. automodule:: pptx.exc
   :members:
   :member-order: bysource
   :undoc-members:
